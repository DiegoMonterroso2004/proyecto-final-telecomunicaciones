"""Verificación académica: no prueba terreno, equipos, IPS ni una red instalada."""
import importlib.util, sys, math, json, unittest
from pathlib import Path
from dataclasses import replace
base=Path(__file__).parent
spec=importlib.util.spec_from_file_location('radio_model',base/'simulador_revisado.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
def altura(d,k):
    return .6*17.32*math.sqrt(d/24)+1000*(d/2)**2/(2*k*6371)
def decidir_ruta(principal,respaldo):
    return 'principal' if principal else ('respaldo' if respaldo else 'sin_servicio')
def permitido(origen,destino,servicio):
    reglas={('empleados','aplicaciones','https'),('voz','central_voz','sip_tls'),('gestion','equipos','ssh')}
    return (origen,destino,servicio) in reglas
class Complementarias(unittest.TestCase):
    def test_margen_10(self):self.assertAlmostEqual(m.calcular(replace(m.Enlace(),sensibilidad_dbm=-79.5))['fm_db'],29.103245,places=5)
    def test_margen_35(self):self.assertAlmostEqual(m.calcular(replace(m.casos()[1][1],sensibilidad_dbm=-79.5))['fm_db'],30.263084,places=5)
    def test_geometria_10(self):self.assertAlmostEqual(altura(10,2/3),9.65103,places=5)
    def test_geometria_35(self):self.assertAlmostEqual(altura(35,2/3),48.601565,places=5)
    def test_presupuesto_disponibilidad(self):self.assertAlmostEqual(3*.0001*365*24*60,157.68)
    def test_conmutacion_logica(self):self.assertEqual(decidir_ruta(False,True),'respaldo')
    def test_falla_doble(self):self.assertEqual(decidir_ruta(False,False),'sin_servicio')
    def test_prioridad_principal(self):self.assertEqual(decidir_ruta(True,True),'principal')
    def test_aislamiento_invitados(self):self.assertFalse(permitido('invitados','aplicaciones','https'))
    def test_gestion_restringida(self):self.assertFalse(permitido('empleados','equipos','ssh'))
    def test_flujo_autorizado(self):self.assertTrue(permitido('gestion','equipos','ssh'))
    def test_capacidad_contingencia(self):
        normal=((15+12+3)*1.15+1.44)*1.25/.7
        esencial=((7.5+4+1)*1.15+1.44)*1.25/.7
        self.assertLess(48,normal);self.assertGreater(48,esencial)
if __name__=='__main__':
    unittest.main(verbosity=2)
