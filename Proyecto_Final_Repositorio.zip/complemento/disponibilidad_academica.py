"""Escenario reproducible; los datos climaticos son supuestos, no validacion del sitio.
P.530-19 eq. 7, 32-36; P.838-3 tabla 5; P.841-7 eq.4.
"""
import math, json, unittest
from pathlib import Path

def multipath(d, altura, margen, K=1e-4, dn75=10, terreno=1500):
    f=6; hc=altura-d*d/102; hL=terreno+altura
    vs=min((dn75/50)**1.8*math.exp(-hc/(2.5*math.sqrt(d))),dn75*d**1.5*f**.5/24730)
    logp0=math.log10(K)+3.51*math.log10(d)+.447*math.log10(f*f+13)-.376*math.tanh((hc-147)/125)-.00027*hL+17.85*vs
    pw=10**(logp0-margen/10)
    limite=(2.85/12)**(1/.13)
    anual=pw/12 if pw<=12*limite else (pw/2.85)**(1/.87)
    return {'hc_m':hc,'vsr':vs,'logp0':logp0,'p0_porcentaje':10**logp0,'pw_porcentaje':pw,'p_anual_porcentaje':anual}

def margen_multitrayecto(d, altura, p=.0025):
    pw=2.85*p**.87
    return 10*(multipath(d,altura,0)['logp0']-math.log10(pw))

def lluvia(d,p=.0025,R=.0):
    R=R or 95
    gamma=.0007056*R**1.5900
    dr=min(d,30)
    r=1/(.477*dr**.633*R**(.073*1.59)*6**.123-10.579*(1-math.exp(-.024*dr)))
    a01=gamma*d*r
    c0=.12;c1=.07**c0*.12**(1-c0);c2=.855*c0+.546*(1-c0);c3=.139*c0+.0431*(1-c0)
    a=a01*c1*p**(-(c2+c3*math.log10(p)))
    return {'gamma_db_km':gamma,'r':r,'deff_km':d*r,'A001_db':a01,'A_p_db':a,'p_porcentaje':p,'C1':c1,'C2':c2,'C3':c3}

def balance(d,D,P):
    G=10*math.log10(.6*(math.pi*D/.05)**2)
    L=92.45+20*math.log10(6)+20*math.log10(d)
    Pr=P+2*G-L-4
    N=-174+10*math.log10(40e6)+6
    return {'ganancia_dbi':G,'potencia_rx_dbm':Pr,'snr_db':Pr-N,'reserva_25_db':Pr-N-25,'fm_db':Pr+79.5}

def resultados():
    rows=[]
    for nombre,d,H,D,P in [('Base 10 km',10,30,.6,23),('Base 35 km',35,60,1.2,23),('Reforzado 35 km',35,60,1.8,28)]:
        b=balance(d,D,P);am=margen_multitrayecto(d,H);r=lluvia(d)
        at=25+1.2*multipath(d,H,0)['logp0']
        a=max(am,r['A_p_db'],at)
        rows.append({'escenario':nombre,'distancia_km':d,'altura_ideal_m':H,'diametro_m':D,'potencia_dbm':P,**b,'multipath':multipath(d,H,b['fm_db']),'lluvia':r,'A_transicion_db':at,'A_m_inversa_db':am,'A_requerido_db':a,'holgura_db':b['fm_db']-a,'cumple_escenario':b['fm_db']>=a})
    return {'aviso':'Supuestos de clima y terreno. No acredita disponibilidad real ni perfil geografico. No simula IPS o paquetes.','supuestos':{'K':1e-4,'dN75':10,'R001_mm_h':95,'cota_terreno_m':1500,'presupuesto_multipath_porcentaje_por_sentido':.0025,'presupuesto_lluvia_porcentaje_por_sentido':.0025},'escenarios':rows}

class Pruebas(unittest.TestCase):
    def test_inversa(self):self.assertAlmostEqual(multipath(35,60,margen_multitrayecto(35,60))['p_anual_porcentaje'],.0025)
    def test_base35_insuficiente(self):self.assertFalse(resultados()['escenarios'][1]['cumple_escenario'])
    def test_refuerzo_suficiente(self):self.assertTrue(resultados()['escenarios'][2]['cumple_escenario'])
    def test_margen_reduce_caidas(self):self.assertLess(multipath(35,60,40)['p_anual_porcentaje'],multipath(35,60,30)['p_anual_porcentaje'])
    def test_lluvia_monotona(self):self.assertGreater(lluvia(35,.005)['A_p_db'],lluvia(35,.01)['A_p_db'])

if __name__=='__main__':
    import sys
    if '--test' in sys.argv:unittest.main(argv=[sys.argv[0]],verbosity=2)
    else:
        out=Path(__file__).with_name('disponibilidad_resultados.json')
        out.write_text(json.dumps(resultados(),ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps(resultados(),ensure_ascii=False,indent=2))
